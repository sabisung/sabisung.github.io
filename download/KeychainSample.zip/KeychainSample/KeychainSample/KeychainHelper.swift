//
//  KeychainHelper.swift
//  KeychainSample
//
//  Created by sabisung on 2021/07/16.
//

import Foundation
import SwiftyJSON

/// Keychain 에러
struct KeychainError: Error {
    var status: OSStatus

    var localizedDescription: String {
        return SecCopyErrorMessageString(status, nil) as String? ?? "Unknown error."
    }
}

/// Keychain
class KeychainHelper {
    private let service: String
    private let account: String
    
    /// 생성자
    /// - Parameters:
    ///   - service: 서비스명
    ///   - account: 계정명
    init(service: String, account: String) {
        self.service = service
        self.account = account
        print("[KeychainHelper] service: \(self.service)")
        print("[KeychainHelper] account: \(self.account)")
    }
    
    /// 생성자
    convenience init() {
        self.init(
            service: Bundle.main.bundleIdentifier ?? "service",
            account: (Bundle.main.bundleIdentifier?.split(separator: ".").last.map(String.init)) ?? "account"
        )
    }
    
    /// 생성자
    /// - Parameter account: 계정
    convenience init(account: String) {
        self.init(
            service: Bundle.main.bundleIdentifier ?? "service",
            account: account
        )
    }
    
    /// 항목 추가
    /// - Parameters:
    ///   - data: 항목 데이터
    ///   - completionHandler: 완료 핸들러
    func addItem(_ data: Data, completionHandler: (Bool, KeychainError?) -> Void) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrGeneric as String: data
        ]
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else {
            completionHandler(false, KeychainError(status: status))
            return
        }
        completionHandler(true, nil)
    }
    
    /// 항목 읽기
    /// - Parameter completionHandler: 완료 핸들러
    func readItem(_ completionHandler: (Data?, KeychainError?) -> Void) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnAttributes as String: true,
            kSecReturnData as String: true
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else {
            completionHandler(nil, KeychainError(status: status))
            return
        }
        guard let existingItem = item as? [String: Any],
              let data = existingItem[kSecAttrGeneric as String] as? Data else {
            completionHandler(nil, KeychainError(status: errSecInternalError))
            return
        }
        completionHandler(data, nil)
    }
    
    /// 항목 수정
    /// - Parameters:
    ///   - data: 항목 데이터
    ///   - completionHandler: 완료 핸들러
    func updateItem(_ data: Data, completionHandler: (Bool, KeychainError?) -> Void) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let attributes: [String: Any] = [
            kSecAttrAccount as String: account,
            kSecAttrGeneric as String: data
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        guard status == errSecSuccess else {
            completionHandler(false, KeychainError(status: status))
            return
        }
        completionHandler(true, nil)
    }
    
    /// 항목 삭제
    /// - Parameter completionHandler: 완료 핸들러
    func deleteItem(_ completionHandler: (Bool, KeychainError?) -> Void) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess else {
            completionHandler(false, KeychainError(status: status))
            return
        }
        completionHandler(true, nil)
    }
}

//
//  ViewController.swift
//  KeychainSample
//
//  Created by sabisung on 2021/07/15.
//

import UIKit
import Security

/// 항목 정의
struct BiometricMapping: Codable {
    let logonId: String?
    let deviceId: String?
}

class ViewController: UIViewController {

    @IBOutlet weak var lblSuccess: UILabel!
    @IBOutlet weak var lblErrorCode: UILabel!
    @IBOutlet weak var lblErrorMesg: UILabel!
    @IBOutlet weak var lblData: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    /// 추가 버튼
    /// - Parameter sender: 버튼
    @IBAction func itemAddTapped(_ sender: UIButton) {
        guard let deviceId = UIDevice.current.identifierForVendor?.uuidString else {
            return
        }
        let biometricMapping = BiometricMapping(logonId: "sabisung@gmail.com", deviceId: deviceId)
        print("biometricMapping: \(biometricMapping)")
        guard let data = try? JSONEncoder().encode(biometricMapping) else {
            return
        }
        KeychainHelper().addItem(data) { (success, error) in
            lblSuccess.text = success ? "성공!!" : "에러!!"
            lblErrorCode.text = String(error?.status ?? 0)
            lblErrorMesg.text = error?.localizedDescription ?? ""
            lblData.text = ""
        }
    }
    
    /// 읽기 버튼
    /// - Parameter sender: 버튼
    @IBAction func itemReadTapped(_ sender: UIButton) {
        KeychainHelper().readItem { (data, error) in
            if error == nil {
                guard let data = data, let biometricMapping = try? JSONDecoder().decode(BiometricMapping.self, from: data) else {
                    return
                }
                print("biometricMapping: \(biometricMapping)")
                lblData.text = "\(biometricMapping)"
            }
            lblSuccess.text = error == nil ? "성공!!" : "에러!!"
            lblErrorCode.text = String(error?.status ?? 0)
            lblErrorMesg.text = error?.localizedDescription ?? ""
        }
    }
    
    /// 수정 버튼
    /// - Parameter sender: 버튼
    @IBAction func itemUpdateTapped(_ sender: UIButton) {
        guard let deviceId = UIDevice.current.identifierForVendor?.uuidString else {
            return
        }
        let biometricMapping = BiometricMapping(logonId: "yycho100@gmail.com", deviceId: deviceId)
        print("biometricMapping: \(biometricMapping)")
        guard let data = try? JSONEncoder().encode(biometricMapping) else {
            return
        }
        KeychainHelper().updateItem(data) { (success, error) in
            lblSuccess.text = success ? "성공!!" : "에러!!"
            lblErrorCode.text = String(error?.status ?? 0)
            lblErrorMesg.text = error?.localizedDescription ?? ""
            lblData.text = ""
        }
    }
    
    /// 삭제 버튼
    /// - Parameter sender: 버튼
    @IBAction func itemDeleteTapped(_ sender: UIButton) {
        KeychainHelper().deleteItem() { (success, error) in
            lblSuccess.text = success ? "성공!!" : "에러!!"
            lblErrorCode.text = String(error?.status ?? 0)
            lblErrorMesg.text = error?.localizedDescription ?? ""
            lblData.text = ""
        }
    }
}


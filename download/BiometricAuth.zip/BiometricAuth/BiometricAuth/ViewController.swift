//
//  ViewController.swift
//  BiometricAuth
//
//  Created by sabisung on 2021/07/14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func biometricAuthWithPasscodeTapped(_ sender: UIButton) {
        if #available(iOS 11.0, *) {
            // 생체인증 실패시 passcode 사용
            BiometricAuth { (success, error) in
                print("[BIO] success: \(success)")
                print("[BIO] error: \(String(describing: error))")
            }.authenticateBiometric()
        }
    }
    
    @IBAction func biometricAuthTapped(_ sender: UIButton) {
        if #available(iOS 11.0, *) {
            // 생체인증 실패시 passcode 미사용
            BiometricAuth(isPasscode: false) { success, error in
                print("[BIO] success: \(success)")
                print("[BIO] error: \(String(describing: error))")
            }.authenticateBiometric()
        }
    }
}


//
//  BiometricAuth.swift
//  BiometricAuth
//
//  Created by sabisung on 2021/07/14.
//

import Foundation
import LocalAuthentication

/// 생체 인증 유형
enum BiometricType {
  case none     // 없음
  case touchID  // 지문
  case faceID   // 안면
}

@available(iOS 11.0, *)
class BiometricAuth {
    private let localizedReason4TouchID = "지문 인식을 활성화하려면 사용자 암호가 필요합니다."
    private let localizedReason4FaceID = "Face ID를 활성화하려면 사용자 암호가 필요합니다."
    private let passcodeInterval: TimeInterval = 0.3
    
    private var biometricPolicy: LAPolicy
    private let completionHandler: (Bool, Error?) -> Void
    private var isPasscode: Bool = true
    
    private var laContext = LAContext()
    
    /// 생성자
    /// - Parameters:
    ///   - biometricPolicy: 생체인증 정책
    ///   - isPasscode: 생체인증 실패시 passcode 사용여부
    ///   - completionHandler: 핸들러
    init(biometricPolicy: LAPolicy, isPasscode: Bool, completionHandler: @escaping (Bool, Error?) -> Void) {
        self.biometricPolicy = biometricPolicy
        self.isPasscode = isPasscode
        self.completionHandler = completionHandler
    }
    
    /// 생성자
    /// - Parameters:
    ///   - isPasscode: 생체인증 실패시 passcode 사용여부
    ///   - completionHandler: 핸들러
    convenience init(isPasscode: Bool, completionHandler: @escaping (Bool, Error?) -> Void) {
        self.init(biometricPolicy: LAPolicy.deviceOwnerAuthenticationWithBiometrics, isPasscode: isPasscode, completionHandler: completionHandler)
    }
    
    /// 생성자
    /// - Parameter completionHandler: 핸들러
    convenience init(_ completionHandler: @escaping (Bool, Error?) -> Void) {
        self.init(biometricPolicy: LAPolicy.deviceOwnerAuthenticationWithBiometrics, isPasscode: true, completionHandler: completionHandler)
    }
    
    /// 소멸자
    deinit {
        self.laContext.invalidate()
    }
    
    /// 생체인증 가능 여부
    /// - Returns: 가능여부
    func canEvaluatePolicy() -> Bool {
        return laContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
    }
    
    /// 기기가 지원하는 생체인증 유형
    /// - Returns: 생체인증 유형
    func biometricType() -> BiometricType {
        if canEvaluatePolicy() {
            switch laContext.biometryType {
            case .none:
                return .none
            case .touchID:
                return .touchID
            case .faceID:
                return .faceID
            default:
                return .none
            }
        }
        return .none
    }
    
    /// 생체인증 진행
    func authenticateBiometric() {
        guard canEvaluatePolicy() else {
            completionHandler(false, NSError(domain: "", code: LAError.biometryNotAvailable.rawValue, userInfo: [NSLocalizedDescriptionKey: "biometry not available"]))
            return
        }
        let bioType = biometricType()
        guard bioType != .none else {
            completionHandler(false, NSError(domain: "", code: LAError.biometryNotAvailable.rawValue, userInfo: [NSLocalizedDescriptionKey: "biometry not available"]))
            return
        }
        
        if !isPasscode {
            laContext.localizedFallbackTitle = "" // 생체 인증 실패시 passcode 입력 불가 처리
        }
        let localizedReason = bioType == .touchID ? localizedReason4TouchID : (bioType == .faceID ? localizedReason4FaceID : " ")
        laContext.evaluatePolicy(self.biometricPolicy, localizedReason: localizedReason) { (success, error) in
            if success {
                self.completionHandler(true, nil)
            } else {
                switch error {
                case LAError.userFallback?: // passcode 입력
                    print("[BIO] userFallback...")
                    self.laContext.invalidate()
                    DispatchQueue.main.asyncAfter(deadline: .now() + self.passcodeInterval) {
                        self.laContext = LAContext()
                        self.biometricPolicy = .deviceOwnerAuthentication
                        self.authenticateBiometric()
                    }
                default:
                    self.completionHandler(false, error)
                }
            }
        }
    }
}

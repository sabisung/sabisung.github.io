//
//  ViewController.swift
//  ImageRotate
//
//  Created by sabisung on 2021/06/18.
//

import UIKit

class ViewController: UIViewController {
    
    /// 스크롤되는 이미지 리스트
    let images: [UIImage] = [
        UIImage(named: "Image-1")!,
        UIImage(named: "Image-2")!,
        UIImage(named: "Image-3")!,
        UIImage(named: "Image-4")!,
        UIImage(named: "Image-5")!
    ]
    /// ImageView 리스트
    var imageViews: [UIImageView] = []
    /// 자동 스크롤 시간 간격
    let TIMER_INTERVAL: TimeInterval = 3
    /// Timer
    var timer: Timer? = nil
    /// 드래깅 여부
    var isDragging: Bool = false
    
    /// 스크롤 뷰
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setup()
    }
    
    /// UI 설정
    func setup() {
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.delegate = self
        
        imageViews = createImageViews()
        if images.count < 3 {
            imageViews.append(contentsOf: createImageViews())
        }
        
        scrollView.isScrollEnabled = images.count > 1
        scrollView.contentSize = CGSize(width: scrollView.frame.width * CGFloat(imageViews.count), height: scrollView.frame.height)
        scrollView.contentOffset = CGPoint(x: 0, y: 0)
        
        layoutImageViews()
        
        startTimer()
    }
    
    /// 스크롤되는 이미지 뷰 생성
    /// - Returns: 이미지 뷰 리스트
    func createImageViews() -> [UIImageView] {
        return images.map { image -> UIImageView in
            let imageView = UIImageView()
            imageView.contentMode = .scaleAspectFill
            imageView.backgroundColor = .clear
            imageView.image = image
            
            scrollView.addSubview(imageView)
            
            return imageView
        }
    }
    
    /// 이미지 뷰 레이아웃 설정
    func layoutImageViews() {
        imageViews.enumerated().forEach { (index, imageView) in
            imageView.frame = CGRect(x: scrollView.frame.width * CGFloat(index),
                                     y: 0,
                                     width: scrollView.frame.width,
                                     height: scrollView.frame.height)
        }
    }
    
    /// 타이머 시작
    func startTimer() {
        guard images.count > 1 else { return }
        stopTimer()
        timer = Timer.scheduledTimer(timeInterval: TIMER_INTERVAL,
                                     target: self,
                                     selector: #selector(timerCallback),
                                     userInfo: nil,
                                     repeats: false
        )
    }
    
    /// 타이머 중지
    func stopTimer() {
        if let t = timer {
            t.invalidate()
        }
        timer = nil
    }
    
    /// 타이머 콜백
    /// - Parameter sender: 타이머
    @objc func timerCallback(_ sender: Timer) {
        var offset = scrollView.contentOffset
        offset.x += scrollView.frame.width
        scrollView.setContentOffset(offset, animated: true)
    }
}

extension ViewController: UIScrollViewDelegate {
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        isDragging = true
        stopTimer()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        isDragging = false
        startTimer()
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        addImageViewAtLast()
        startTimer()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if !isDragging {
            return
        }

        let offsetX = scrollView.contentOffset.x
        
        if offsetX > scrollView.frame.size.width * 1.5 {
            addImageViewAtLast()
        }

        if offsetX < scrollView.frame.size.width * 0.5 {
            addImageViewAtFirst()
        }
    }
    
    /// 첫번째 이미지 뷰를 삭제후 마지막에 삽입
    func addImageViewAtLast() {
        if let imageView = self.imageViews.first {
            self.imageViews.remove(at: 0)
            self.imageViews.append(imageView)
            self.layoutImageViews()
            self.scrollView.contentOffset.x -= self.scrollView.frame.width
        }
    }
    
    /// 마지막 이미지 뷰를 삭제후 처음에 삽입
    func addImageViewAtFirst() {
        if let imageView = self.imageViews.last {
            self.imageViews.removeLast()
            self.imageViews.insert(imageView, at: 0)
            self.layoutImageViews()
            self.scrollView.contentOffset.x += self.scrollView.frame.width
        }
    }
}


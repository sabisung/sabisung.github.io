//
//  MyAppConfig.swift
//  MyAppDev
//
//  Created by sabisung on 2021/05/10.
//

import Foundation

enum MyAppConfig {
    enum Variant {
        case dev
        case staging
        case release
    }
    
    static func getVariant() -> Variant {
        return .dev
    }
    
    static let EXEC_ENV_NAME = "개발"
}

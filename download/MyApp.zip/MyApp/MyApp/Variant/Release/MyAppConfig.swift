//
//  MyAppConfig.swift
//  MyApp
//
//  Created by sabisung on 2021/05/10.
//

import Foundation

enum MyAppConfig {
    enum Variant {
        case dev
        case staging
        case release
    }
    
    static func getVariant() -> Variant {
        return .release
    }
    
    static let EXEC_ENV_NAME = "배포"
}

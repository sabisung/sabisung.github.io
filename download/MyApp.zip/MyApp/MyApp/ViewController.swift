//
//  ViewController.swift
//  MyApp
//
//  Created by sabisung on 2021/05/10.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        print("실행환경: \(MyAppConfig.getVariant())")
        print(" EXEC_ENV_NAME: \(MyAppConfig.EXEC_ENV_NAME)")
        
        guard let apiKey: String = Bundle.main.infoDictionary?["API_KEY"] as? String else { return }
        print(" apiKey: \(apiKey)")
    }


}


//
//  InitViewController.swift
//  ChangeRootVC
//
//  Created by sabisung on 2021/06/23.
//

import UIKit
import Alamofire
import RxSwift

class InitViewController: UIViewController {

    @IBOutlet weak var initImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let mainViewController = self.storyboard?.instantiateViewController(withIdentifier: "MainViewController") as! ViewController
        
        randomImageDownload("https://picsum.photos/800/600?random", completionHandler: { [weak self] data in
            print("Image Download Done...")
            self?.initImageView.image = UIImage(data:  data)
            
            mainViewController.transImageSubject.onNext(UIImage(data:  data))
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute: {
            print("Switch to MainViewController...")
            UIApplication.shared.delegate?.window??.rootViewController = mainViewController
            mainViewController.transImageSubject.onCompleted()
        })
    }
    
    /// 이미지 다운로드
    /// - Parameters:
    ///   - urlString: URL
    ///   - completionHandler: 완료 핸들러
    func randomImageDownload(_ urlString: String, completionHandler: @escaping (Data) -> Void) {
        AF.request(
            urlString,
            method: .get
        )
        .response { resp in
            let response: DataResponse<Data?, AFError>? = resp
            
            guard response?.error == nil else {
                print("ERROR: \(String(describing: response?.error.debugDescription))")
                return
            }
            
            guard let data = response?.data else {
                print("ERROR: No Image")
                return
            }
            
            completionHandler(data)
        }
    }
}

//
//  ViewController.swift
//  ChangeRootVC
//
//  Created by sabisung on 2021/06/23.
//

import UIKit
import RxSwift

class ViewController: UIViewController {
    
    private var disposeBag = DisposeBag()
    let transImageSubject = BehaviorSubject<UIImage?>(value: nil)

    @IBOutlet weak var mainImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        transImageSubject
            .debug("ViewController")
            .subscribe(onNext: {
                self.mainImageView.image = $0
            })
            .disposed(by: disposeBag)
    }
}

